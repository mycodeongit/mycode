#!/bin/bash
# Depending on VCF version launch the appropriate vxverify version and pass all parameters
# >=3.9.1 - vcfv4
# <3.9.1  - vcfv3
# hardcoded version for logic test:
# ver="3.9.1"
# ver="4.5"
# ver="3.9.2"
# ver="4.0.0"
# ver="4.0.1"
# ver="4.2.0"
# ver="4.3.0"
SCRIPT=`realpath $0`
SCRIPTPATH=`dirname $SCRIPT`
cd $SCRIPTPATH
echo "Running essential SOS healthchecks, prior to running VCF-Verify."
/opt/vmware/sddc-support/sos --ntp-health --general-health --password-health --services-health --dns-health --skip-known-host-check
# /opt/vmware/sddc-support/sos --certificate-health --skip-known-host-check
echo "Checking VCF version"
sddc=$(curl -s -k http://localhost/sddc-manager-ui-app/about | json_pp | grep version | awk '{print $3}' | awk -F "-" '{print $1}' | tr -d "\"")
pver=$(python --version | awk '{print $2}')
function version { echo "$@" | awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }'; }
#if [ $(version $ver) -ge $(version "3.7.5") ]; then
echo "SDDC Manager $sddc"
echo "Python version $pver"
if [ $(version $pver) -ge $(version "3.8.0") ]; then
    echo "Current Python is too high for VCFVerify"
elif [ $(version $pver) -ge $(version "3.7.0") ]; then
    #echo "Version is 3.9.1 or greater"
    python vcfv4.pyc "$@"
else
    echo "Version is less than 3.9.1, which is not supported yet by VCFV"
    # python vcfverify3.pyc "$@"
fi
