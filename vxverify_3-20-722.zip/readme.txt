VxVerify aims to simplify the pre-upgrade testing of VxRail clusters by checking of nodes and system VM by automatically 
uploading scripts to each host and automating the analysis of the data that is returned.  VxVerify is written and maintained 
by Escalation Engineering, in order to have tests for new issues within days of them being diagnosed.

- VxVerify 1.xx.xxx is for VxRail 4.0 only
- VxVerify 2.xx.xxx is for VxRail 4.5, 4.7 & 7.0.000
- VxVerify 3.xx.xxx is for VxRail 7.0.010+ (a new version is necessary due to the move to Python 3.6 from 2.7, in VxRail 7.0.010 onwards)
- VCFVerify is for SDDC Manager and runs the VxVerify versions above on each VxRM in VCF.

For help with downloading, installing and running VxVerify, see KB article:
    https://www.dell.com/support/kbdoc/000021527

Troubleshooting: See KB article:
    https://www.dell.com/support/kbdoc/000066460

Tests marked with a * are in draft mode (no warnings or failures should be returned), to be fully released at a later date.

Recent changes:
x.20.722 (expiry date: 2022 Aug 14)
VxTii report for nodes has had the iDRAC revision added (VXV-567)
Test 'unmap' added, to check if the vSAN unmap setting has been enabled (VXV-555)
Test 'rancher' amended to check multiple containers with the same label (VXV-566)
Colour scheme for VxTii cluster information changed to cyan (VXV-565)
VLCM status added to the Vx credentials output in vxverify_tests.json (VXV-232)
Fixed issues with VxRM test results, which occur when the marvin site_package cannot be reached (VXV-564)
Reduced unnecessary lines in vxv.log to improve readability (VXV-574)
*Test 'ipv4vmk' added to alert if IPv4 is enabled on vmk0, which can cause upgrade problems for 7.0.350+ (VXV-115)
*Test 'bootdisk' updated to exclude all G series nodes (VXV-229)

x.20.715 (expiry date: 2022 Aug 05)
VxTii cluster report added to vxtii.txt, with vCenter and VxRM key information for Support (VXV-502)
The VxTii cluster information will now be echoed to the screen, between the LCM report and the healthcheck table (VXV-565)
Test 'dcism' disabled for VxRail 8.0+, due to change of service name to dellism (VXP-56899)
Test 'df_vc' has disk space warning thresholds increased from 70% to 80% (the failure threshold is still 85%). Mount points with 'archive' or 'backup' in the path are excluded from this test.  (VXV-557)
Test 'op_status' added, to check the size of mysticmanager operation_status DB table (VXV-553)

x.20.708 (expiry date: 2022 Jul 29)
Test 'vc_api' added, to consolidate failure messages for API failures into a single critical event (VXV-554)
Test 'nic_hwi' will now not give a warning for Intel NIC if no target code level is provided. Given that the target code levels with the relevent issue are no longer available, this test should now not trigger for Intel NIC (VXV-552).
Test names containing vrm (short for VxRail Manager), renamed to vxm (also short for VxRail Manager), for consistency (VXV-541).
* Test 'adv_mod' added, to validate if the cluster is in a LCM advanced mode state (VXV-279)
* Test 'ds_state' updated to replace test 'dvs_out' (VXV-82)

x.20.630 (expiry date: 2022 Jul 20)
One issue that can cause false alarms for the node tests is a second copy of VxVerify that has been initiated from a different source. To avoid this, VxVerify will check for other recently updated VxVerify logs and will pause, for up to 200 sec, to let the other VxVerify complete (VXV-545)
File naming change for minion and host json files to avoid conflicts with other minions that may be triggered on the same host (VXV-545)
Changes in host file cleanup functions to avoid deleting files from other minions (VXV-545)
Test 'dvs_out' removed from upgrade profiles (VXV-549)
Fix for VCSA tests where SSH errors could just return the status 'True' (VXV-548)
Branding change to replace all Dell EMC references with Dell (VXV-551 & VXP-57991)

x.20.624 (expiry date: 2022 Jul 14)
Test 'dnslookup' will check each VxRM nameserver entry separately, with a forward DNS lookup of the vCenter FQDN (VXV-547)
For non-vSAN nodes, tests that use vSAN commands, such as 'witness', will be bypassed (VXV-544)
Fix for reverse DNS lookup, which can still return an IP instead, since IPv6 support was added in x.20.617 (VXV-543)
Fix for issue in VxV2 VCSA tests where a necessary parameter is missing, causing SSH to fail (VXV-546)
VCSA tests will not give a warning for no root password if there is an external vCenter or the core test profiles are used (VXV-506)
Test 'ip9090' event added for when either the SSL Cert or key file is missing (VXV-542, VXP-49188)

x.20.620 (limited release)
Test 'pconf' adapted to support IPv6, without or with IPv4 (dual stack).  The reverse IPv6 lookup of the bind entry will not be done for IPv6 nodes (VXP-49188)
Adding additional argument error handling, prior to starting the logs (VXV-537)
Fix for overall result of VxRM tests which can mistakenly return a 3 (VXP-49188)

x.20.617 (expiry date: 2022 Jul 07)
Changes to the way node names and the FQDN are used to reduce issues for customers with stale reverse DNS entries (VXV-535)
Tests 'px_vcsa', 'df_vc' & 'dvs_out' changed to give a unified response for VC SSH failures, which can be adjusted according to the test profile (VXV-506 & VXV-533)
Test 'saved_pw' to report a fail for out-of-family upgrades when the settings table encrypted password does not match runtime.properties (VXV-534)
Base64 password support added to VxVerify2, to match VxVerify3. This allows passwords with escape characters to be supplied as arguments, which otherwise would cause problems with the Shell (e.g. -w base64:UGFzc3dvcmQxMjMh) (VXV-518)
Fix in function 'dns_fqdn_ip' for an exception with the error handling string (VXV-539)
Test 'primnodes' excluded from core test profiles (VXV-529)

x.20.610 (expiry date: 2022 Jun 30)
Dual stack IPv4/IPv6 support added to VxVerify3 (VXP-49188)
Test 'mservices' fixed for blank systemctl responses, which indicates a service not running (VXP-54816)
Test 'vc_fqdn' added, which reads VirtualCenter.FQDN from VC mob via pyvomi (VXV-314)
Test 'dns_node' modified to allow IPv6 nameserver entries and to replace the reverse DNS lookup query, with forward lookup queries using each specified nameserver (VXV-121)
Arguments ''--in_family','-i' and '--oo_family','-o' are being removed. The test profile should be determined by the target code level or can be manually specified with the '--number','-n' arguments (VXV-489)
Test 'ntp-node' set to not run for IPv6 dual stack nodes, pending further testing in these environments (VXP-49188)
Test 'vxnode' modified to not run on nodes without iDRAC (VXP-49188)

x.20.530 (expiry date: 2022 Jun 20)
Profiles 6 & 7 added, which include the core upgrade tests only, for use by Dell Support in conjunction with other health-checks.  Note that for customer upgrades, the use of the in and out of family test profiles is still recommended (profiles 1 & 2) (VXV-516).
Added argument -c / --core <target_code>, to activate test profiles 6 or 7 to the specified target code.  This replaces the use of --target for these upgrade use cases (VXV-516).
Launch script 'vxverify.sh' has been updated to prompt for vSphere Administrator credentials (-u & -p arguments), which will be needed for some future tests (VXV-77)
Test 'nic710' has been renamed to 'nic_hwi' and expanded to include checking for combinations of BCM5741x & BCM5750x NIC, which can cause upgrades to fail, if BCM5750x are below firmware '21.85.21.92' (VXP-55093 & VXV-510)
Extra parsing added for entries in configuredHosts, without a valid host name (VXV-521)
Expanded 'hoststatus' test to cover invalid configuredHosts, which would be reported under '_cluster' (VXV-521)
Fix for NVMe drives in VXT, where there is more than one drive per PCI slot number (using different bay/bus numbers) (VXT-515)
Fix for 'dnslookup' to report forward DNS lookup failures, if there are any, instead of reverse failures (VXV-513)
Profile change for 'dnslookup' to not report reverse DNS failures in the core upgrade profiles (6 & 7) (VXV-505)
Profile change for all 'vsh_*' (vSAN Health), to not report in the core upgrade profiles (6 & 7) (VXV-517)
Fix for test profile numbers in VxVerify2, which were not always correctly generated from the target code level (VXV-514)
Additional information from the vxv.log will be saved into the vxverify_tests.json, for ease of searching, such as DNS information and the test profile number (VXV-507 & VXV-509)
In the VxTii report, NIC Slot names have been abbreviated to fit into the table (VXV-511)
In the VxTii report, faults that trigger the 'vxtii_err' health-check, will be included in the 'Recommendations For Support', if there are not already recommendations there from the LC log analysis (VXT-515).
Test 'tag_sfs' added, which reads SFS related Tags on VxRail (VXV-332)
Test 'vc_trust' added for pre 7.0.240, which adds check for valid CRL files and is able to verify VC connection if VC certificate issued by SubCA (VXV-504)
Test 'vc_camode' added, which reads vpxd.certmgmt.mode from VC via pyvomi (vxv2 & vxv3) - VXV-500

x.20.520 (expiry date: 2022 Jun 12)
TxTii reports in VxVerify 3, will begin with a section for vSphere and VxRail cluster information, before the sections for each node, unless the single node report is specified (VXV-502)
When polling nodes using Python based SSH, a total number of tests completed will be listed, to give a better indication of progress (VXT-330)
Test 'lcm_state' silenced except for API errors and added additional logging (VXV-481)
Test 'ip9090' added certificate for 7.0.350+ mTLS requirement, which fixes handshake failures (VXV-491)
TxTii reports for single CPU models will not longer show the second CPU as: CPU info missing (VXV-389)
Log clearing procedure modified to have more granular error handling to cope better with zip files that the user does not have permission to rename (VXV-508)
Logging for functions prior to log files being opened has been enhanced.  These info. or error events will be cached and then replayed into the log files once they are open (VXV-508)
Test "vr_pw_char" will no longer include warnings for unspecified root passwords, which instead will be a separate warning (VXV-506)

x.20.513 (expiry date: 2022 Jun 05)
Fix for incorrect host results when an older run of VxVerify was left in a sub-directory of the new logging folder (VXV-493)
Test 'qedentv' changed to not apply to upgrade test profiles (VXV-484)
Test 'snoop' restricted to VxVerify3 only, with the VxRail 4.x upgrades being covered by notes in Solve (VXT-579)
Test 'mservices' changed to not report the 'active (exited)' status as a fault, pending further investigation (VXV-480)
Fix for test profile numbers in VxVerify3, which were not always correctly generated from the target code level (VXV-489)
Test 'ip_reserve' added to check for IP addresses that are reserved in specific code levels (VXT-727).
Test 'vxm_cert' fixed for variable referenced before assignment (VXV-490)
Test 'clom' changed to only run for VxRail 4.5 (VXV-126)
Test 'vcsize' changed to identify the 'VMware vCenter Server Appliance' VM from the vmx file or Annotation, rather than the VM name (VXT-744)
Test 'vcsize' removed from test profile 2 (in-family upgrade) (VXV-105)
VxTii memory event action plans updated (VXV-389)
ESXi host test profiles adjusted to make sure only the necessary tests are run (VXV-496)

x.20.506 (expiry date: 2022 May 29)
Change made to the VCSA password testing, to run a bad password character check only if the login fails, not if it logs in successfully (VXT-738).
VM names used for vMotion testing will be trimmed to remove unprintable characters (VXT-731).
Test 'vxnode' removed from upgrade test profiles (VXT-745)
Test 'vcsize' will no longer report a warning if the vCenter Server Appliance VM cannot be found (usually due to it being renamed) (VXT-744)
Test 'dns_node' will not test reverse DNS in upgrade test profiles (VXV-121)
Test 'ntp_node' will not be included in upgrade test profiles (VXT-742)
Test ‘vmk_tag’ adjusted to not give warnings for the management tag being on other vmk for additional profiles (VXT-208)

x.20.429 (expiry date: 2022 May 22)
* Test 'bootdisk' added to check Boot drive RAID 1 mirroring (VXT-713).
Test 'dcism' modified to accept the response 'iSM is running' in addition to 'iSM is active (running)' (VXT-719).
Test 'sp_svm' fixed to handle a failed storage profile search for the management VM (VXT-725).
Test 'nic710' modified to take into account the target code level (VXT-439).
Test 'hoststatus' modified for Quanta nodes, which do not have the node name listed in the nodes DB table and therefore reported a DB entry missing (VXT-732).
VxTii node boot drive summary will now show a fault when the RAID 1 status on either drive is not Online, in addition to either drive not being listed as 'OK' (VXT-713)
Summary table changed to clarify invalid test records, caused by unprintable VM names (VXT-731)
Arguments -u and -p are being repurposed to input the VC Administrator user and password, rather than overriding the saved Management user and password (VXT-728)

x.20.413 (expiry date: 2022 May 06)
Test 'ifcfg' added to check the static IP configuration for VxRM (VXT-618).
Added tests 'vc_trust' - test if VXM can establish trusted connection to VC with certificates found in VXM trust folders (and it will log files found which are not in correct DER or PEM format), and certificates retrieved from VC (VXT-525, VXT-526).
Added test 'vxm_cert_check' - test if VXM certificate is: self-signed, FQDN match with ca.cnf if self-signed, can be validated against trust file, has expired (VXT-637).
Change to test 'dcism' to correctly report iSM is not running, rather than not responding (VXT-690).
Change to 'ds_pgroup' to use existing global variables without having to query VC unnecessarily (VXT-694).
Change to vxverify_history.gz archiving to avoid losing the internal vxverify_history.zip suffix (VXT-697).
Change to copyright notice to match the rest of the ADC/radar framework (VXT-699).
Change to 'lcm_status' test as pre 7.0.130 needs authentication to work (VXT-664).
Change to test 'thump', to handle thumbprint separator in 7.0.350+ correctly (VXT-701).
Host JSON filenames will change per release, to avoid conflicts from multiple VxVerify runs (VXT-714).

x.20.329 (expiry date: 2022 Apr 21)
Logging change being phased in to prefix log events with the test name that they are associated with (VXT-668).
Added ESXi HBA driver and firmware levels to the VxTii report (VXT-672).
Added test 'hbadriver' for problematic HBA driver levels on 15G nodes (VXT-670).
Added test 'privileges' which checks the VC management user role privileges (VXT-598).
Added test 'ds_perm' which checks that the vCenter management account has permission at datastore level (VXT-598).
Added test 'rancher' that replaces tests dockr_svc and dockr_ver for 7.0.370+ (VXT-639)
Test 'rp4vm' will return to only giving a warning, now that supported versions of RecoverPoint are available for VxRail 7.0.3xx (VXT-682).
Consolidated VxVerify log bundle will also be saved to a single file (vxverify_history.gz), for ease of collection (VXT-660).
Change behaviour for node1 argument (-a node1=...), to run no minions if its specified, but does not closely match any node name (VXT-683).
Fix for reporting in test 'mservice' (VXT-680).

x.20.318 (expiry date: 2022 Apr 10)
Change to 7.x microservice commands to account for variations in the ip command between releases (VXT-651).
Timeout added for the total time that all microservice queries are allowed (VXT-652).
Change to SSH in VxV3 to get public keys from hosts, rather than using the VxRM known_hosts keys (VXT-636).
Test 'dohost' added to check the validity of the do-host package records (VXT-625). While this test is in beta, all responses will be 0-Pass.
Fix for test 'vc_ntp' to fail more clearly when DO is not responding to a '{vc {currentTime } }' query (VXT-662).
Added logging of additional config_service data, that is not yet used, as the basis of a health-check (VXT-566).

x.20.309 (expiry date: 2022 Apr 01)
Fix for 'dns_xref', which had unclear log entries and did not correctly read punctuation correctly in the DB entry (VXT-644)
Fix for ‘dcism’ to exclude any nodes without iDRAC (VXT-642)
To prevent the test 'mservices' from incorrectly flagging up the rabbitmq having a status of active (exited), rabbitmq status will not be tested until its tolerable states are better documented (VXT-643)
Critical test responses for Python exceptions will instead return the status 'Py Crash', to make it clearer that these need a VXT to be raised, but by themselves do not prevent an upgrade (VXT-641).
Extra large writing added for critical events in summary table (VXT-641)
When critical failures occur, nodes that do not have the critical failures will also show a warning to emphasise that nothing has a clean bill of health when some tests may not have been run (VXT-641).  For example, when saved passwords are wrong, testing is aborted as a critical alert.

x.20.304 (expiry date: 2022 Mar 27).
Test 'mservices' added for running services on management VM, such as runjars (VXT-616 & VXT-429).
Fix for Python based SSH to set the ESXi SSH status back to the same Running/Stopped value it was at the start of VxVerify (VXT-632).
Zip log bundle renaming has been changed to find multiple vxverify zip bundles and renumber them all as vxv_previous-0?.zip (VXT-633).
Test 'ip9090' will not log failures for VxRail 7.0.350+ due to an SSL issue that is still under investigation (VXT-580)
Tests 'pwe_root' & 'pwe_mystic' are modified to not run for other users which would not have permissions to run the chage commands (VXT-634)

x.20.225 (expiry date: 2022 Mar 18)
Layout change for summary table to use longer test result status and fewer KB digits (VXT-581)
Tests 'df_tmp' & 'in_tmp' have free space warning thresholds increased to 70%, for /tmp on each node that is used for VCF (otherwise it is 20%) (VXT-577).
Test 'dns_xref' can produce false alarms if internal DNS is used, so having no entries in resolv.conf will no longer produce a test failure (VXT-549)
Test 'vxnode' added to check the vxnode.config file on VxRail 7.0.240+ nodes (VXT-516)
Test 'sys_vm' added to compare the VxRM VM information from the Management DB and vCenter (VXT-530).

x.20.221 (expiry date: 2022 Mar 14)
VxVerify2 has revised Python package importing to prevent errors on VxRail 4.5, which is missing packages that are necessary for new tests (VXT-611).
Added fallback option to internal queries for VxVerify3 if the Docker option fails (VXT-601).

x.20.218 (expiry date: 2022 Mar 11)
API calls for VxVerify3 changed to allow host based testing to run from the mystic user.  Many VC and VxRM based tests still require root permissions to run and will fail when run from mystic (VXT-585).
Timeouts added to Shell commands to prevent VxVerify stalling when there are insufficient permissions (VXT-585).
Added test 'snoop_dvs' to check that the DVS multicast-filtering-mode is set to 'snooping' (VXT-579).
Added new event to 'esx_vers' for when a node is missing version and build information in the VxRM DB, which can happen for converted VxRack VCF (VXT-491).
Added new event to 'esx_vers' to state if no valid host records are found, as opposed to no valid host results being received (VXT-491).
Fix for issue in test 'root_user', in VCF environments, that can return a critical error (VXT-590)

x.20.211 (expiry date: 2022 Mar 03)
Test 'dcism' changed to give a fail if the dcism-netmon-watchdog query fails (VXT-570).
LC log queries are reduced for upgrade health-checks to reduce each minion takes to run (VXT-571).
Wording changed after the VxVerify report to list all the saved zip files, including those from previous runs, requesting that they be uploaded to the SR.
Test 'vxrver' added to verify the vxrail_version listed in the config service (KB 196060 & VXT-530).
Test 'dns_xref' can produce false alarms if internal DNS is used so temporarily setting some responses as a pass until we have more use cases coded (VXT-549 & VXT-546)

x.20.205 (expiry date: 2022 Feb 23)
Fixed an error in VxVerify3 that produced the event: not all arguments converted during string formatting (VXEE-9697)
Test 'dns_xref' added for Nameserver comparison between DB and resolv.conf, to make sure no entries have been manually added (VXT-549 & VXT-546)
Test 'vmk-tag' changed to tolerate alternative management vmk, other than for VCF. A fail will still result if there is no management vmk (VXT-370)
Test 'clu_hemon' added to verify the VxRail Cluster Health Monitoring Status (VXT-515)
Fixed expiry date not being passed correctly to the completed JSON (VXT-557)
ESXi bootbank tests modified to make it a failure if imgdb.tgz is missing (VXT-562).
SSH error handling improved with more specific events in vxv.log replacing some exception traces (VXT-547)

x.20.128 (expiry date: 2022 Feb 16)
Added test profile 5 for post-upgrade healthchecks (including unsuccessful upgrades) (VXT-555).
Added test 'sp_svm' added to check that the VxRM Storage Policy is 'VXRAIL-SYSTEM-STORAGE-PROFILE' (VXT-530)
Added test 'dns_xref' to cross reference the DNS settings on VxRM with each of the nodes (VXT-546)
Added further canonical checking for user arguments, such as the logging path (VXP-49452).
Changes made to Python SSH timeout values (VXT-547).
Reduced the number of df queries used by the ESXi minion by caching the result of a single query (VXT-370)
Changing test 'vmk_tag' to apply to test profiles 0, 1 & 5 (VXT-370).

x.20.121 (expiry date: 2022 Feb 09)
Test 'root_user' added for VCF clusters, to detect the user root being used by VxRM for ESXi nodes, instead of a  management user (VXT-504)
Test 'lcm_state' added to check the current LCM Upgrade status (VXT-414).
Test 'tag_clust' added to verify the VxRail Cluster Tag (VXT-485).
Modified test 'IP9090' to ignore nodes that have not yet been upgraded to 7.x, even if VxRM is 7.x (VXT-539).
Improvements to the Python SSH/SFTP for completed JSON to match the Shell based commands (VXT-523).
VxV3 'df_root' and 'df_store2' tests rewritten to use Python, rather than Shell df commands (VXP-23912).

x.20.118 (expiry date: 2022 Feb 06)
Fix for issue with System VM naming that could cause the results of one node to be missing from the output table (VXT-531).

x.20.114 (expiry date: 2022 Feb 02)
Improvements to the minion polling for completed JSON to avoid stale file search results from the node causing the JSON upload to eventually timeout (VXT-523).
Added argument '-m' or '--map', which will generate a VM-UUID JSON file, for use by VxStat for performance analysis of stats.db files (VXT-514).
Added functions to read product names from the config service on VxRM and from IPMI on ESXi (VXP-48830).
No valid hosts returned from VxRM DO or DB, will return a critical failure and cut short any further minion actions (VXT-519).

x.20.107 (expiry date: 2022 Jan 26)
Improved VxTii node package now contains minions for both Python 3.8 (VxRail 7.0.200+) and 3.5 (other releases).
Changes to the product naming in logging and data structures (VXP-48830).
Added an additional flush for log data, before the minion logs are added to the zip file (VXT-207).
VxVerify 2 & 3 global credentials renamed for consistency between the two code streams (VXP-48830).
Reformatted the vSAN healthcheck in the minion txt file, to remove unnecessary characters (VXT-460).
Adding extra checks on arguments to prevent invalid user arguments being accepted (VXT-502).
Retiring test 'vc_build', which is also covered by the 'vc_drift' test (VXT-391).

x.11.220 (expiry date: 2022 Jan 12)
Improved clean-up of JSON from previous VxVerify logs. If a user moved these from a subdirectory, these would have subsequently caused stale results (VXT-499).
Added a password character check for ESXi minion timeouts (the check already is run if the initial SSH connection is rejected) (VXT-499).
Fix for importing of the paramiko module from the VxRail 7.0.350 site packages (VXP-23912).
Fix for test 'bcom5_25g', which could return a Critical error if the linkspeed information from iDRAC was missing (VXT-508).

x.11.210 (expiry date: 2022 Jan 02)
Test 'idc_hwi' added to parse the iDRAC Hardware Inventory, to find issues such as the Dell EMC prefix being incorrectly added to the VxRail Model name.  This replaces the check for the same issue in the 'ipmi' test (VXT-468).
VxTii only mode messaging improved to make it more clear that most healthchecks are not being run (VXT-494).
Expiry date is added to the days remaining line, in the VxVerify summary report and to the release notes (VXT-496).
Profile names will be listed alongside the test profile number in the summary table (VXT-391).
Improved support for non-ascii characters in vMotion results, which could otherwise cause VxVerify to not display the test results (VXT-495).

x.11.203
Test 'eth1_up' added for 4.x to 7.x upgrades to make sure VxRM ETH1 has the Up status (VXT-477)
Test 'vmk_tag' has been modified to provide a list of all vmk tags, in the minion log, to make it easier to see which alternative port may have been tagged as Management (which would give a warning) (VXT-370).
Removed exact duplicate events, for tests such as for 'dns_node', so that only the first node will list them in the table (VXT-330).
Added clearer message for VxVerify3 when no host information can be retrieved from DO (VXT-479)
Default VCF type changed from 1 to 2, if there is no vmk listed in _cluster (VXT-480)
Support for VxRail 7.0.350 improved, with changes to the 'thump' test and paramiko SSH (VXP-44926)
VxVerify3 - new test for VxRail-Cluster-Tag custom attibute - plugin does not work from 7.0.240+ if not present (VXT-485)
Improved the messaging when VxVerify3 has insufficient permissions to run, such as when only using the mystic user (VXT-474).
Test 'ipmi' will also check for 'Dell EMC', incorrectly being prefixed onto the VxRail model name (VXT-468).
When hostd is not responding, the minion VM testing will return a failure labelled as 'hostd - Connection refused to hostd' (VXT-460).

x.11.125
Test 'dockver' significantly reduces the time taken to check docker images (VXT-345).
VxVerify3 changed any remaining Shell commands to not use shell=True (VXP-23912)
vMotion test parsing added to ignore repeat warnings for VM on each host while upgrading key events to 2-Fail (VXP-44926).
VxVerify3 will now give a clearer error that the mystic user does not have sufficient permissions to run it (VXT-474)
VxVerify3 will use SSL connections if version 7.0.240 or higher (VXP-36746)

x.11.119
Change in summary table layout to remove the 0, 1 or 2 for pass, warn or fail (VXT-469).
Fix for vMotion tests where not all node results were being added to the output table (VXT-467).
Test 'tools' has had the event "Tools Installer Mounted" changed from a warning to a fail, because this would stop a host going into maintenance mode (VXP-44926).
Function added to clarify the meaning of API fault response codes, for the vxv.log (VXT-459).
The target code parameter is now passed to the minion, for this to be used in code specific tests (VXT-391)
Tests 'gpuhw' and 'rp4vm' will give a fail instead of a warning, if target code 7.0.300+ is specified (VXT-466 & VXT-461).  E.g. -g 7.0.300
Increase 'ntp_node' test failure criteria for time drift to be 5 mins for profiles 1 and 2 (upgrades) (VXT-473)

x.11.111
Added test 'snmp_md5' to warn if SNMP is using MD5 authentication (VXT-426).
Test 'vcf_type' changed to only give a warning, not a fail, if VCFVerify is being used (VXT-451).
Changed test 'cnf_state' to accept a configurationstate for an unconfigured node (VXT-444).
Test 'vcsize' changed to apply to upgrade test profiles, but not routine healthchecks (VXT-391).
VxTii SE Logs time period changed to count back from the time the report was run, not the time from the most recent event.
Added revised test 'ip9090' to check that port 9090 is open for 14G nodes when upgrading from 7.0.010 and above. This test now runs from VxRM, which the minion based test (VXT-298).

x.11.105
Added test 'vmk_tag' to make sure the interface tag for vmk0 is set to 'Management' (VXT-370)
Added test 'dcism' to verify that the DC iSM watchdog is running (VXT-424).
Change in test 'hoststatus', to allow for FQDN in the VxRM node DB table (VXT-367).
Fix for some hosts not listing the completed JSON correctly via SSH, even if all tests completed (VXT-435).
Test 'nic710' changed to apply to 7.0.000+ and to use iDRAC data, rather than esxcli vxrail, which does not work for 7.0.240+ (VXT-439)
Added argument --target, -g, which allows the code version to be specified that the upgrade is intended for.  This will dictate whether the upgrade tests are for in or out of family and is mutually exclusive with other test profile arguments (i.e.: -i, -o or -n) (VXT-391).

x.11.020
Timeout made consistent for all VxVerify versions, which will be 30 mins for minions to run, or 20 mins for the embedded VxRM version (VXT-408).
Improved error handling for incomplete host entries, which could otherwise lead to the VxVerify JSON results not being saved (VXT-422)
Fix for the Paramiko SFTP process for downloading minion JSON files, if the minion fails (VXT-421)

x.11.015
Added a retry mechanism for failing iDRAC commands, which would otherwise cause VxTii and iDRAC test failures, along with clearer reporting if the retry also fails (VXT-409 & VXT-410).
Added ESXi version query in VxVerify3, which can trigger a different minion to be sent if some nodes are on a lower VxRail release than VxRM (VXT-412).
Improved error handling in minion_host_list function, to cope with incomplete host records (VXT-415).
Changing VM 'tools' test to check the InstallerMounted value, rather than toolsStatus (VXP-43931).
Improved reporting for minions failing due to failing SSH connections (VXT-406).
Decreasing the iDRAC log period reviewed by VxTii from 30 to 14 days (VXT-413).

x.11.008
VxVerify 2.11 and 3.11 support test profiles, for in or out of family upgrades, as well as for general health-checks (VXT-391).
Argument -n ? added, for specifying the profile number.  This is an alternative to using specific arguments for each profile, so -i or -n 1 are the same.  These arguments are mutually exclusive to avoid contradictions (VXT-391).
Added test 'ipv6vmk', to check for IPv6 Port Groups (VXT-347).
Test 'pconf' modified to only apply to 14G or 15G nodes at 7.0.130 or higher (VXT-369 & 384)
Added change to VxTii and the 'vsandrv' test to correct the iDRAC drive primarystatus being listed as 'unknown' (VXT-404)
Test 'dblogs' now takes into account the free space in the logs folder.  The test will only produce an alert if there are excessive logs and the free space is under 2GB (warning) or 1GB (test failure).
Support added to adjust the VxVerify version lifespan, when additional parameters are specified (VXT-394).
The test profile number has been added to the test summary table header (VXT-391).
The 'mem_c' test event 'IPMI error logging disabled', will not appear in upgrade test profiles, but will be a warning in routine health-checks.
Test results can now overflow onto a second line, if necessary, in the VxVerify test result table (VXT-383).
LCM History has been moved to above the VxVerify result table (VxT-383)
Added test 'ipv6_vmk', to verify that nodes have both IPv4 and IPv6 port groups, for out of family upgrades (VXT-347).

x.10.930
Removed test 'esxpw_char', if the minion has successfully run, proving the node password worked (VXT-392).
Test 'rp4vm' modified to include either either .dell or .emc in the search string (VXT-328).
Fixed issue where "nic710" test can return an invalid response for 7.0.200+ (VXT-375)
Node test 'sboot' is being retired (VXT-391).
Renaming of VxRM will no longer give a warning, because that issue only applied when upgrading to 7.0.010 (VXT-385).
Test 'sboot' is being retired (VXT-391).
MD5 files have been added to each zip file, for the pyc files in that same file.
Adding support for arguments -i (In family upgrade) and -o (Out of family upgrade) (VXT-391).

x.10.924
Added GPU table for Integrated Graphics and nVidia cards, to the VxTii report (VXT-359)
Added test 'pconf' for VxRail 7.0.130+, to cross reference the bind IP in platform.conf against the node's IP (VXT-369).
Test 'hoststatus' has a cross referencing of the node DB table added to the existing checks for the management_account and vxrailhost tables (VXT-367)

x.10.917
Added test 'gpuhw' to highlight any additional GPU cards (i.e. Nvidia), which would need to be upgraded separately (VXT-359)
Fix for bad formatting in the VxTii actions table (VXT-361)
The warning threshold has been changed for each node's NTP test to trigger when reach is 0, which indicates that the NTP server cannot be reached (VXT-348).
vMotion tests changed for VxVerify3 to match VxVerify2 (VXT-326).
In --vcf mode, VxVerify will stream logs to stderr, so that the vxv log files can be saved and monitored in realtime on SDDC Manager (VXT-349).
The VxTii header layout has been changed to include the reports date-time in GMT (VXT-361).
Corrected issue where not running all VM tests could result in test 'vcsize' reporting the VCSA sizing information was missing (VXT-331).

x.10.910
Added test 'nic710' for nodes that have both 'x710' and any of 'i350', 'x520', 'x540' or 'x550' (VXT-326).
Decreased the staggered minion start delay from 10 to 5 seconds (VXT-349).
Test result for VxRM virtual disk partitions upgraded to a fail instead of a warning (VXT-338)
vMotion test results for VxVerify2, moved into the host VM results, effectively replacing tests such as 'tools' and 'vmdk_vsan' (VXT-302 & VXT-243)
Rather than give a warning for each node not running the full VM tests, an entry is added into the test aim table to say the 'iso' tests were not run (along with 'vmdk' and 'pcip') (VXT-331)
Site package 'vxv3_python.zip' added, which includes the Python module Paramiko.  VxV3 will unpack and install the zip if it is present in the specified log folder.  This is not needed from 7.0.300 onwards, because those site-packages will be present in VxRM. (VXP-23912 & VXT-349)
VxVerify3 can now use the Python SSH and SFTP functions (Paramiko), to replace the existing Shell based SSH and SCP commands for the minion.  If the site-packages are available the minion polling messages will change to poll all the minions as they run. (VXT-349)
The use of Shell based SSH/SCP can be forced using the -f,-fix parameter (VXT-349).
Added extra debugging to VxTii tables to better handle unexpected FRU errors (VXT-350)
VxVerify will normally not upload a new minion if the existing minion has the same version as VxVerify, but an update can now be forced using the -f, -fix argument (VXT-349).

x.10.902
Moving ESXi tests, which repeat the same warnings for each node, into the _cluster category (e.g. df_vsan and vibsx), to only run on one node (VXT-330).
Fix for Samsung NVMe drives producing invalid VxTii entries (VXT-323)
Increased the severify of test 'esx_vers', when no ESXi node versions can be found in the JSON, when something (probably unsupported password characters), caused the minions to fail (VXT-301).

x.10.826
Changed the JSON location for node credentials (without passwords), to be consistent for VxV2, VxV3 and VCF-Verify.
Fix the -s, --service argument in VxV minion, to make sure it prevents the platform service restart and does not clear the iDRAC Queue (VXP-41815).
Changed the iDRAC queue clearing to only use the Force option if the --fix (-f), argument is specified.
Amended test 'dblogs' to not apply to releases without folder /var/lib/pgsql/data/log, such as VxRail 4.5 (VXT-304)
Amended the warning for VCSA tests being bypassed, to not apply in Radar mode (VXP-41629).
Changing individual VM tests to only run when additional arguments are supplied. These tests are partially duplicated by the vMotion compatibility check (VXT-302).
Changed test 'dockr_ver' to make it clear that docker revisions that are too high are an issue too.

x.10.820
Added test 'dns_node' to ESXi minion, which reads the nameserver values and performs a reverse DNS lookup test (VXT-291).
Added test 'dblogs', which counts the PSQL logs on VxRM, to verify that the auto-delete cronjob is running (VXT-284).
Fixed the site-package path for VxRail 4.5
Increasing the warning for VxRM root permissions to a fail, because it would failure in other tests, like pwe_mystic.
Added the date-time and VxRail version to the VxVerify summary table
Changed log chmod to be less verbose and to only modify files produced as VxVerify runs.
Changed the VxRail version query to not use the Shell (VXP-23912)
Removed Port Group check on VxRack (VXT-304)

x.10.805
Added warnings for test sections skipped using the -x parameter, which should not be used for pre-upgrade healthchecks.
New VCF-Verify test 'liclib' for VCF licencing issues
New VCF-Verify test 'sd_task' for stuck SDDC tasks (KB
Seach order for site-packages was changed to also include '/mystic/radar/venv/lib/python2.7/site-packages'

x.10.803
Tightened the search for non-vSAN nodes, to prevent them incorrectly being flagged up as 'compute only'.
Added more logging to minions for compute only nodes, to retain the HWinventory
Test 'vc_pw_char': changed to prioritise the illegal characters (such as $ ` \ ), over dubious ones like !, in the failure message.
Improved 'drs' test to fail on disabled drs and manual drs mode, to flag a warning on partially automated.
Fixed 'dockr_ver' bug for issue with VXP-26020
Fixed 'dockr_ver' bug with 7.0.010 and 7.0.100 VxRM not detecting docker image versions "ERROR Failed docker validation due to missing validation files" as in VXT-275

x.10.723
Added 'dnslookup' test, checks the count of DNS errors from other functions and then also does a reverse DNS lookup test.  This test was added because DNS errors can lead to false alarms in other tests, like 'primnodes' (VXT-266 & VXT-269).
Added 'dockr_ver' test to validate running Docker image versions to be up to date
VxRM test 'mapper' now checks the free space in all the /dev/mapper partitions, with warnings and failures at 80% and 90% respectively.  Other tests that looks at specific partitions, like store2, have lower thresholds (VXT-257).

x.10.720
Improved compute-only node support, to bypass vSAN testing (VXP-35934).
BMC test will be bypassed in VxRail 7.x releases with no PTagent (VXP-39111 & VXP-37523)
Workaround for iDRAC based tests added to minion, to not run for 7.0.240+, due to changes in the way the commands work for iDRAC "5.00.10.00".

x.10.713
Added 'rm_bmo' test to check bind mount
Fix in 'rm_snap' for VXT-249.
Fixed pwe tests to make sure they do not run for logins that the local user does not have permissions to check.

x.10.709
Moved VMtools check (i.e. 'tools' test per VM), to just the verbose mode (-d, --debug or --verbose)
Added 'pwe_root' and 'pwe_mystic' tests, to check for password expiry dates on VxRM.
Added test for NSX passwords in VCF Verify.
Entering just 0 for a password (or up to 7 letters), in the VxVerify arguments, will give a prompt to instead enter that password securely (VXT-248).
Corrected NTP KB from 44270 to 42270 (VXT-259).

x.10.624
Cluster test 'vc_size' added, to compare the VCSA CPU count and RAM against the current total, to see if the VCSA size needs increasing.
When no root password is supplied for VCSA, a warning will now be returned.
Added epoch time value to tests for use when using VxVerify as a VxRM plugin (Radar).
Changed default encoding in VxVerify2 to be UTF-8, to prevent API response decoding errors (VXT-241 & VXT-217).

x.10.610
Added test 'vcbuild' to make sure VC EP have not been applied, prior to VxRail upgrades (VXT-231).
Added test 'rm_snap' to check VxRM Snapshots age and amount is not violating rules set in KB 188210.
Test cpumx, for CPU compatibility removed from minion, which is no longer required.
Cluster credential queries adjusted to cope with missing values in the config service.
Modified bmc test to cope with more types of failed query.
Changed host cross referencing to prevent shorter IP addresses matching longer addresses (VXEE-8434)
Added PSC root user and password handling, to enable checks similar to those for VCSA.
Added xGrail password file export option.

x.10.603
Added VxRM 7.x test 'mapper', to spot partitioning errors following upgrades from 7.0.010
Reduced the amount of messages logged for resetting host alarms in vxv2.

x.10.527
Modifying TMP event search to look for all-clear events TMP0123 and TMP0205, which should cancel critical action plans.
Adding more LC Log codes to be filtered out of VxTii report, such as JCP027 & JCP037
Altered DB search for Primary nodes to  correctly set the Primary status on each host record.
Modified VxRM name check to ignore VCF clusters.
Amended the search in the 'iplisten' test, to pick up alternative naming of hostd (VXT-210).

x.10.520
Added support for non-vSAN nodes, which bypasses vSAN related tests (VXP-35934).
Added check that /var/log/vmkernel.log is a link to that file in scratch, added to scratch test (VXT-204).
Added check for 'Bad magic number', when running the minion, which indicates that a pyc compiled for a different Python version was used (VxRail 7.0.200+ uses Python 3.8 instead of 3.5)
VxRM 'root_test', which was disabled when no tests needed root permissions, has been enabled again, to highlight that some tests are incomplete without root (e.g. thump).
If a host being tested cannot create a JSON and error will be added to the list.
Check to make sure that there are no files using the names that the vxv folders require and removing them if necessary (VXT-201).
Fixed issue where cleanup of json files after the minion results from one host are downloaded could delete files from other hosts before they too were downloaded.

x.10.514
VxVerify2 & 3 no longer produce cookie files (VXP-31228).
Added test 'iplisten', to make sure all essential ESXi services are listening to IP connections.
Added test 'vxtii', to flag up issues noted in the VxTii report to the VxVerify health-checks.
Changed SSH test to use the Python socket command instead of exec in the shell.
Added node UID into 'ESXi' section of the node JSON, to make it easier to match results to JSON files later on.

x.10.507
Output tables changed to increase the brightness of some colours, such as red and blue.
Performance improvements in LCM upgrade history search, increases searching rate by 500%.
Added more debugging for iDRAC information, so that the HWInventory will be saved if there are errors, or if verbose mode is enabled.

x.10.430
Fixed test 'primnodes', which can miscount number of primary nodes in some releases, due to formatting differences in the vxrailhost DB table.
Reduced the log events for LC log events outside of time range, to a count of the ignored events.

x.10.428
Added test 'vsandrv', which checks the vSAN drive bay status from VxTii.  Missing disks would block upgrades and this test will be more specific for failures than the vSAN healthcheck.
VxTii drive bay table has changed the logic to list the total working drives, not the total disks found.
If sufficient lines of gz lcm logs have already been read, the rest will be skipped to save time.
Added test to count the primary nodes in a cluster.  There can be only one!
Changed query for config service and lockbox to log clearer events, if the query fails.

x.10.416
The System VM are now cross referenced to provide their node owner, in vxverify_tests.json
Logging format in minion changed to be more consistent with vxv.log
Changed node diskfree_bootbank test to cope with larger bootbanks (over 500MB)
Changed the search string for vSAN names to accept more special characters.
VCSA tests report expired root passwords, rather than just the resulting SSH error.
iDRAC IP for each node is now read by the minion and saved into the returned JSON.
VCFVerify now passes the VCSA root password to VxVerify, to allow VCSA tests to be run from each domain.
Test 'vmtools', which gave a pass for 'notrunning', adjusted to do the same for 'notinstalled'.

x.10.409
Added SOS output parsing to VCFVerify
Expanded bootbank test to also check state.tgz.
Modified check for local site packages, so that it only applies when running scripts from the vxtii folder.

... Update notes from previous releases prior to this are archived.
